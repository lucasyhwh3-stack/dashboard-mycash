
  # Implementar Sidebar com Navegação

  This is a code bundle for Implementar Sidebar com Navegação. The original project is available at https://www.figma.com/design/LCUp3VsExVJN2YvQRFSNB5/Implementar-Sidebar-com-Navega%C3%A7%C3%A3o.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  