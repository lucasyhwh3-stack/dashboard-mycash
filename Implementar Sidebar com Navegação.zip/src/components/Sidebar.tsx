import { useState } from "react";
import { ChevronLeft, ChevronRight, Home, CreditCard } from "lucide-react";
import svgPaths from "../imports/svg-mh5o0rxfn5";
import imgMembers from "figma:asset/2d2d4de26d16019c939c7468d658dc71ae4fb8f0.png";

function Logo({ collapsed }: { collapsed: boolean }) {
  return (
    <div className={`flex items-center gap-[12px] transition-all ${collapsed ? "justify-center" : ""}`}>
      <div className="h-[43px] w-[45px] shrink-0">
        <svg className="block size-full" fill="none" preserveAspectRatio="none" viewBox="0 0 45.4611 43.1816">
          <g>
            <path d={svgPaths.p14e2600} fill="#060A11" />
            <path d={svgPaths.p3036ef00} fill="#060A11" />
            <path d={svgPaths.p26159200} fill="#060A11" />
            <path d={svgPaths.p6735480} fill="#060A11" />
            <path d={svgPaths.p2546980} fill="#060A11" />
            <path d={svgPaths.p7266a00} fill="#060A11" />
            <path d={svgPaths.pbb75a40} fill="#060A11" />
          </g>
        </svg>
      </div>
      {!collapsed && (
        <div className="flex items-center gap-[2px] text-[#080b12] font-['Inter:Semi_Bold',sans-serif] font-semibold text-[20px] leading-[28px]">
          <span>mycash</span>
          <span className="text-[#d7ff00]">+</span>
        </div>
      )}
    </div>
  );
}

interface MenuItemProps {
  icon: React.ReactNode;
  label: string;
  active?: boolean;
  collapsed: boolean;
}

function MenuItem({ icon, label, active, collapsed }: MenuItemProps) {
  return (
    <button
      className={`flex items-center gap-[8px] px-[16px] py-[12px] rounded-[100px] transition-all w-full ${
        active
          ? "bg-[#d7ff00]"
          : "hover:bg-gray-100"
      }`}
    >
      <div className="shrink-0 size-[16px]">{icon}</div>
      {!collapsed && (
        <span className="text-[#080b12] font-['Inter:Regular',sans-serif] font-normal text-[14px] leading-[20px] tracking-[0.3px]">
          {label}
        </span>
      )}
    </button>
  );
}

interface SidebarProps {
  className?: string;
}

export function Sidebar({ className = "" }: SidebarProps) {
  const [collapsed, setCollapsed] = useState(false);

  return (
    <div
      className={`bg-white relative flex flex-col h-screen justify-between p-[32px] transition-all duration-300 ${
        collapsed ? "w-[80px]" : "w-[240px]"
      } ${className}`}
    >
      {/* Toggle Button */}
      <button
        onClick={() => setCollapsed(!collapsed)}
        className="absolute bg-white flex items-center justify-center p-[4px] right-[-12px] top-[67px] rounded-full shadow-[0px_4px_4px_0px_rgba(0,0,0,0.25)] z-10 hover:scale-110 transition-transform"
        aria-label={collapsed ? "Expandir sidebar" : "Colapsar sidebar"}
      >
        <div className="size-[16px]">
          {collapsed ? <ChevronRight className="size-full" /> : <ChevronLeft className="size-full" />}
        </div>
      </button>

      {/* Top Section */}
      <div className="flex flex-col gap-[56px]">
        <Logo collapsed={collapsed} />
        
        {/* Menu */}
        <nav className="flex flex-col gap-[4px]">
          <MenuItem
            icon={<Home className="size-full" strokeWidth={2} />}
            label="Home"
            active={true}
            collapsed={collapsed}
          />
          <MenuItem
            icon={<CreditCard className="size-full" strokeWidth={2} />}
            label="Cartões"
            collapsed={collapsed}
          />
        </nav>
      </div>

      {/* Bottom Section - User Profile */}
      <div className={`flex items-center gap-[12px] ${collapsed ? "justify-center" : ""}`}>
        <div className="shrink-0 size-[40px] rounded-full overflow-hidden">
          <img
            alt="User avatar"
            className="size-full object-cover"
            src={imgMembers}
          />
        </div>
        {!collapsed && (
          <div className="flex flex-col min-w-0">
            <p className="font-['Inter:Semi_Bold',sans-serif] font-semibold text-[14px] leading-[20px] text-[#080b12] truncate">
              João Silva
            </p>
            <p className="font-['Inter:Regular',sans-serif] font-normal text-[12px] leading-[16px] text-[#6b7280] truncate">
              joao@example.com
            </p>
          </div>
        )}
      </div>
    </div>
  );
}
