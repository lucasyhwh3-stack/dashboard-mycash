import { Sidebar } from "./components/Sidebar";
import { Search, Settings, Calendar, Plus, TrendingDown, TrendingUp, CreditCard as CardIcon, ChevronRight } from "lucide-react";
import imgMembers1 from "figma:asset/18ce5dd32b29293835b5ed37e9daa6be03009f96.png";
import imgMembers2 from "figma:asset/af653292c77a2fe70e1975968fc1e683de087b18.png";
import imgNubankLogo from "figma:asset/104735c9164e2efb4290fa655bd47ea2b28be0e7.png";
import imgInterLogo from "figma:asset/9947ddd88ee4489faa5d8ed9b00e21de304ef2db.png";
import imgPicpayLogo from "figma:asset/26d52142a70858c0b396955ffc0a8d5d4f15c755.png";

export default function App() {
  return (
    <div className="flex min-h-screen bg-[#f3f4f6]">
      {/* Sidebar */}
      <Sidebar />

      {/* Main Content */}
      <div className="flex-1 flex flex-col">
        {/* Top Navbar */}
        <header className="bg-[#f3f4f6] px-[40px] py-[24px] border-b border-[#e5e7eb]">
          <div className="flex items-center justify-between">
            {/* Search and Filters */}
            <div className="flex items-center gap-[8px]">
              <div className="flex items-center gap-[8px] px-[24px] py-[12px] rounded-full border border-[#9ca3af] bg-white w-[175px]">
                <Search className="size-[16px] text-[#080b12]" />
                <input
                  type="text"
                  placeholder="Pesquisar"
                  className="flex-1 text-[14px] leading-[20px] text-[#080b12] bg-transparent outline-none placeholder:text-[#9ca3af]"
                />
              </div>
              
              <button className="flex items-center p-[12px]">
                <Settings className="size-[16px] text-[#080b12]" />
              </button>
              
              <div className="flex items-center gap-[8px] px-[24px] py-[12px] rounded-full border border-[#9ca3af] bg-white">
                <Calendar className="size-[16px] text-[#080b12]" />
                <span className="text-[14px] leading-[20px] text-[#080b12]">01 Jan - 31 Jan 2026</span>
              </div>
            </div>

            {/* Members and New Transaction */}
            <div className="flex items-center gap-[24px]">
              {/* Members */}
              <div className="flex items-center">
                <img src={imgMembers1} alt="Member" className="size-[44px] rounded-full border-2 border-white" />
                <img src={imgMembers2} alt="Member" className="size-[44px] rounded-full border-2 border-white -ml-[12px]" />
                <button className="size-[44px] rounded-full border-2 border-white bg-[#d1d5db] flex items-center justify-center -ml-[12px]">
                  <Plus className="size-[24px] text-[#080b12]" />
                </button>
              </div>

              {/* New Transaction Button */}
              <button className="bg-[#080b12] flex items-center gap-[8px] px-[16px] py-[12px] rounded-full">
                <Plus className="size-[16px] text-white" />
                <span className="font-semibold text-[18px] leading-[24px] text-white">Nova transação</span>
              </button>
            </div>
          </div>
        </header>

        {/* Main Dashboard Content */}
        <main className="flex-1 px-[40px] py-[32px] overflow-auto">
          {/* Category Cards */}
          <div className="grid grid-cols-4 gap-[18px] mb-[30px]">
            {[
              { label: "Aluguel", value: "R$ 4.000,00", percent: "25%" },
              { label: "Alimentação", value: "R$ 2.000,00", percent: "15%" },
              { label: "Mercado", value: "R$ 1.500,00", percent: "5%" },
              { label: "Academia", value: "R$ 120,00", percent: "3%" }
            ].map((item, index) => (
              <div key={index} className="bg-white rounded-[20px] border border-[#e5e7eb] p-[24px] flex flex-col items-center gap-[12px]">
                <div className="relative w-[72px] h-[72px]">
                  <svg viewBox="0 0 72 72" className="transform -rotate-90">
                    <circle
                      cx="36"
                      cy="36"
                      r="32"
                      fill="none"
                      stroke="#e7e8ea"
                      strokeWidth="8"
                    />
                    <circle
                      cx="36"
                      cy="36"
                      r="32"
                      fill="none"
                      stroke="#c4e703"
                      strokeWidth="8"
                      strokeDasharray={`${parseInt(item.percent) * 2.01} 201`}
                      strokeLinecap="round"
                    />
                  </svg>
                  <div className="absolute inset-0 flex items-center justify-center">
                    <span className="text-[12px] leading-[20px] text-[#080b12]">{item.percent}</span>
                  </div>
                </div>
                <div className="text-center">
                  <p className="text-[14px] leading-[20px] text-[#080b12] mb-[4px]">{item.label}</p>
                  <p className="font-bold text-[20px] leading-[28px] text-[#080b12]">{item.value}</p>
                </div>
              </div>
            ))}
          </div>

          {/* Summary Cards */}
          <div className="grid grid-cols-3 gap-[20px] mb-[40px]">
            <div className="bg-white rounded-[20px] border border-[#e5e7eb] p-[24px] flex flex-col gap-[32px]">
              <CardIcon className="size-[24px] text-[#080b12]" />
              <div>
                <p className="text-[18px] leading-[28px] text-[#080b12] mb-[4px]">Saldo total</p>
                <p className="font-bold text-[28px] leading-[36px] text-[#2a89ef]">R$ 2.000,00</p>
              </div>
            </div>

            <div className="bg-white rounded-[20px] border border-[#e5e7eb] p-[24px] flex flex-col gap-[32px]">
              <TrendingDown className="size-[24px] text-[#15be78]" />
              <div>
                <p className="text-[18px] leading-[28px] text-[#080b12] mb-[4px]">Receitas</p>
                <p className="font-bold text-[28px] leading-[36px] text-[#080b12]">R$12.000,00</p>
              </div>
            </div>

            <div className="bg-white rounded-[20px] border border-[#e5e7eb] p-[24px] flex flex-col gap-[32px]">
              <TrendingUp className="size-[24px] text-[#e61e32]" />
              <div>
                <p className="text-[18px] leading-[28px] text-[#080b12] mb-[4px]">Despesas</p>
                <p className="font-bold text-[28px] leading-[36px] text-[#080b12]">R$ 10.000,00</p>
              </div>
            </div>
          </div>

          {/* Cards & Accounts Section */}
          <div className="bg-white rounded-[20px] border border-[#e5e7eb] p-[24px] mb-[32px]">
            <div className="flex items-center justify-between mb-[24px]">
              <div className="flex items-center gap-[8px]">
                <CardIcon className="size-[24px] text-[#080b12]" />
                <h2 className="font-bold text-[20px] leading-[28px] text-[#080b12]">Cards & contas</h2>
              </div>
              <div className="flex items-center gap-[8px]">
                <button className="size-[32px] rounded-full border border-[#e5e7eb] flex items-center justify-center hover:bg-gray-50">
                  <Plus className="size-[16px] text-[#080b12]" />
                </button>
                <button className="size-[32px] rounded-full border border-[#e5e7eb] flex items-center justify-center hover:bg-gray-50">
                  <ChevronRight className="size-[16px] text-[#080b12]" />
                </button>
              </div>
            </div>

            <div className="space-y-[16px]">
              {[
                { logo: imgNubankLogo, name: "Nubank", value: "R$ 120,00", due: "Vence dia 10", cardLast4: "5897" },
                { logo: imgInterLogo, name: "Inter", value: "R$ 2.300,00", due: "Vence dia 21", cardLast4: "5897" },
                { logo: imgPicpayLogo, name: "Picpay", value: "R$ 17.000,00", due: "Vence dia 12", cardLast4: "5897" }
              ].map((card, index) => (
                <div key={index} className="flex items-center justify-between py-[12px]">
                  <div className="flex items-center gap-[16px]">
                    <div className="size-[32px] shrink-0">
                      <img src={card.logo} alt={card.name} className="size-full object-contain" />
                    </div>
                    <div>
                      <p className="font-semibold text-[16px] leading-[24px] text-[#080b12]">{card.name}</p>
                      <p className="text-[14px] leading-[20px] text-[#6b7280]">{card.due}</p>
                      <p className="text-[12px] leading-[16px] text-[#9ca3af]">Crédito {card.name}, **** {card.cardLast4}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-[20px] leading-[28px] text-[#080b12]">{card.value}</p>
                    <p className="text-[14px] leading-[20px] text-[#6b7280]">**** {card.cardLast4}</p>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </main>
      </div>
    </div>
  );
}
